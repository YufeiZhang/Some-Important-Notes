import cv2
import math
import numpy as np

ix,iy = -1,-1

# mouse callback function
def blur(event,x,y,flags,param): # this function show do the blur thing
    global ix,iy,img,mask

    if event == cv2.EVENT_LBUTTONDOWN:
        x0,y0 = len(img),len(img[0])
        ix,iy = x0-y, y0-x # this must be here for locate the mouse
        
    elif event == cv2.EVENT_LBUTTONUP:
        
        Ib = cv2.GaussianBlur(img,(37,37),0)
        
        for i in range(len(img)):
            for j in range(len(img[0])):
                # using the function
                img[i][j] = mask[i+ix][j+iy]*Ib[i][j] + (1-mask[i+ix][j+iy])*img[i][j]        


def buildMask(img): # build the mask
    x0,y0 = len(img),len(img[0]) # 324, 486
    mask = [[0 for _ in range(2*y0)] for _ in range(2*x0)]
    
    for x in range(len(mask)):
        for y in range(len(mask[0])):
            try:
                mask[x][y] = math.exp( -((x-x0)**2+(y-y0)**2)/1600) # follow the function
            except:
                continue
    return mask


img = cv2.imread("ex1.jpg",0)
cv2.namedWindow('image')
cv2.setMouseCallback('image',blur)
mask = buildMask(img)

while(1):
    cv2.imshow('image',img)
    k = cv2.waitKey(1) & 0xFF
    if k == 27:
        break

cv2.destroyAllWindows()
