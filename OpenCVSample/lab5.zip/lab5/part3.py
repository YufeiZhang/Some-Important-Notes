import cv2
import numpy as np

img0 = cv2.imread("ex2.jpg",0)
cv2.namedWindow('image')
img = img0

def nothing(x):
    pass

# create trackbars for color change
cv2.createTrackbar('R','image',0,255,nothing)
cv2.createTrackbar('G','image',0,255,nothing)


while(1):
    cv2.imshow('image',img)
    k = cv2.waitKey(1) & 0xFF
    if k == 27:
        break

    # get current positions of four trackbars
    r = cv2.getTrackbarPos('R','image')
    g = cv2.getTrackbarPos('G','image')

    img = cv2.Canny(img0,r,g)
cv2.destroyAllWindows()
