import numpy as np
import cv2
from matplotlib import pyplot as plt

img = cv2.imread("ex2.jpg",0)
kernalX = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
kernalY = np.array([[-1,-2,-1],[0,0,0],[1,2,1]])

cv2.imshow("img",img)
x = cv2.filter2D(img,-1,kernalX)
y = cv2.filter2D(img,-1,kernalY)
xy = cv2.add(x,y)

plt.subplot(221), plt.imshow(img,"gray"), plt.title("Initial")
plt.subplot(222), plt.imshow(xy,"gray"), plt.title("xy")
plt.subplot(223), plt.imshow(x,"gray"), plt.title("x")
plt.subplot(224), plt.imshow(y,"gray"), plt.title("y")

plt.show()
